---
name: beautiful-prose
description: "Hard-edged writing style contract for timeless, forceful English prose without AI tics"
source: "https://github.com/SHADOWPR0/beautiful_prose"
risk: safe
---

# Beautiful Prose

## Overview

Hard-edged writing style contract for timeless, forceful English prose without AI tics

## When to Use This Skill

Use this skill when you need to work with hard-edged writing style contract for timeless, forceful english prose without ai tics.

## Instructions

This skill provides guidance and patterns for hard-edged writing style contract for timeless, forceful english prose without ai tics.

For more information, see the [source repository](https://github.com/SHADOWPR0/beautiful_prose).
